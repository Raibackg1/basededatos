# 🔬 Detector de Patrones de Trading — Memecoins pump.fun

Herramienta que analiza tu base de datos SQLite (tokens + trades on-chain + tus posiciones)
y descubre **qué patrones mejoran tu winrate** cuando snipeas lanzamientos de memecoins en pump.fun.

## ¿Qué hace?

1. **Inspecciona tu base automáticamente** — detecta tablas y columnas (no requiere nombres fijos:
   `mint`/`token_address`, `entry_price`/`buy_price`, `block_time`/`timestamp`… todo se mapea solo).
2. **Calcula 4 definiciones de "win"** a la vez:
   | Etiqueta | Significado |
   |---|---|
   | `win_real` | Tu PnL cerrado fue positivo |
   | `win_tp_sl` | El precio tocó +TP% antes que −SL% (ruta real de trades) |
   | `win_fut_5m/15m/30m` | Retorno ≥ umbral N minutos después de tu entrada |
   | `win_grad` | El token graduó (completó la bonding curve / migró a Raydium) |
3. **Minería de patrones sin fuga de datos**: solo usa información que tenías
   *en el momento de entrar* (microestructura acumulada hasta tu entrada, momentum de los
   15s previos, si el dev ya había comprado/vendido, concentración de wallets, socials, hora…).
   Nunca usa el resultado (PnL, precio futuro) como "característica".
4. **Optimiza tus salidas**: simula un grid TP×SL sobre las rutas de precio reales de tus
   entradas y te dice qué combinación maximiza expectancy (R) y cuál maximiza winrate.
   Incluye MFE/MAE (cuánto llegó a subir/bajar cada trade antes de cerrarse).
5. **Genera un reporte HTML autocontenido** con reglas IF-THEN ordenadas por lift y
   significancia, gráficos de winrate por nivel de característica, importancia de features,
   curvas ROC e interacciones entre pares de condiciones.

## Instalación

```bash
pip install pandas numpy scikit-learn matplotlib scipy
```

## Uso

### Probar con datos sintéticos (recomendado primero)
```bash
python main.py --demo
```
Genera `demo_pumpfun.db` (1.200 tokens, ~135k trades, ~450 posiciones) con patrones
ocultos a propósito y los redescubre. Sirve para validar que todo funciona.

### Analizar TU base de datos
```bash
python main.py --db /ruta/a/tu_base.db
```

### Opciones
```bash
python main.py --db mi.db \
    --tp 100 --sl 40 \                # tu TP/SL habitual para win_tp_sl (%)
    --future-threshold 20 \           # umbral % de los wins futuros
    --horizons 5,15,30 \              # horizontes en minutos
    --mapping mapping.json \          # corrección manual del mapeo (ver abajo)
    --out resultados                  # carpeta de salida
```

### Salidas
- `resultados/reporte.html` — **el reporte completo** (ábrelo en el navegador; no necesita internet)
- `resultados/hallazgos.csv` — todas las reglas y estadísticas univariadas para filtrar en Excel
- Resumen por consola con las reglas top y la mejor política TP/SL

## Si el mapeo automático falla

La consola imprime el mapeo detectado. Si una columna no se reconoció, crea un
`mapping.json` y pásalo con `--mapping`:

```json
{
  "my_trades": {"table": "posiciones_cerradas",
                 "columns": {"entry_price": "precio_entrada", "pnl_sol": "ganancia"}},
  "trades":    {"table": "swaps_pumpfun"},
  "tokens":    {"table": "lanzamientos", "columns": {"graduated": "migro_a_raydium"}}
}
```

Tipos de tabla que busca: `tokens` (metadata), `trades` (flujo de compras/ventas de todos),
`my_trades` (tus posiciones) y `ohlcv` (velas, opcional).

**Sin tabla `my_trades`**: el modo virtual simula una entrada de sniping estándar a los 10s
de cada token y analiza patrones de *selección* (qué tokens merecen snipearse).

## Cómo interpretar los resultados

- **lift**: winrate del patrón ÷ winrate base. `1.6x` = 60% más de aciertos que tu media.
- **p_valor**: probabilidad de ver esa diferencia por azar. Usa reglas con `p < 0.05` **y** `n ≥ 30`.
- **AUC del modelo**: <0.55 casi no hay señal; 0.6–0.7 señal explotable con filtros; >0.75 fuerte
  (desconfía si es altísimo: puede haber fuga o overfitting).
- **Expectancy (R)**: ganancia media por trade en múltiplos de tu riesgo. Es más importante que
  el winrate: un sistema 30% winrate con +300%/−50% gana más que uno 80% con +20%/−50%.

## Limitaciones (léelas)

1. **Overfitting**: con <200 operaciones los patrones suelen ser ruido. Re-ejecuta al acumular más datos.
2. **Múltiples comparaciones**: se prueban cientos de cortes; algunos saldrán "significativos" por azar.
   Exige p pequeños y sentido común (la regla debe tener una historia causal).
3. **Slippage/MEV**: la ruta de precios observada no es tu ejecución real en sniping.
4. **El mercado cambia**: los patrones de memecoins decaen en semanas; re-entrena periódicamente.
5. Esto es una herramienta de análisis, **no consejo financiero**.

## Estructura del proyecto

```
pumpfun_detector/
├── main.py              # CLI y orquestación
├── demo_data.py         # generador de base sintética con patrones ocultos
└── detector/
    ├── config.py        # parámetros (Cfg)
    ├── inspector.py     # inspección de esquema + mapeo semántico
    ├── loader.py        # carga y normalización (fechas, sides, precios, rutas)
    ├── features.py      # ingeniería de características (token + entrada)
    ├── labels.py        # etiquetas de win, MFE/MAE, grid TP×SL
    ├── patterns.py      # univariado, reglas de árbol, modelo, interacciones
    └── report.py        # reporte HTML autocontenido + recomendaciones
```
