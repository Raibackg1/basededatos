#!/usr/bin/env python3
"""
Detector de patrones de trading para memecoins de pump.fun.

Uso:
    python main.py --db mi_base.db                 # analiza tu base de datos
    python main.py --demo                          # genera datos sintéticos y los analiza
    python main.py --db mi_base.db --mapping mapping.json --tp 100 --sl 40

Salida: resultados/reporte.html, resultados/hallazgos.csv + resumen por consola.
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from detector.config import Cfg
from detector.features import desc, token_features, trade_features
from detector.inspector import apply_mapping_override, inspect_db, schema_report
from detector.labels import build_virtual_trades, compute_trade_labels, mfe_mae_summary, tpsl_grid
from detector.loader import load_data
from detector.patterns import feature_spread, interactions, model_eval, tree_rules, univariate
from detector.report import LABEL_NAMES, build_report


def log(msg: str) -> None:
    print(msg, flush=True)


def main() -> int:
    ap = argparse.ArgumentParser(description="Detector de patrones — sniping pump.fun")
    ap.add_argument("--db", help="Ruta a la base de datos SQLite (.db/.sqlite)")
    ap.add_argument("--mapping", help="JSON opcional para corregir el mapeo automático de tablas/columnas")
    ap.add_argument("--tp", type=float, default=50.0, help="Take profit %% para win_tp_sl (defecto 50)")
    ap.add_argument("--sl", type=float, default=30.0, help="Stop loss %% para win_tp_sl (defecto 30)")
    ap.add_argument("--future-threshold", type=float, default=20.0,
                    help="Umbral %% de ganancia para win_fut_Nm (defecto 20)")
    ap.add_argument("--horizons", type=str, default="5,15,30", help="Horizontes futuros en minutos (defecto 5,15,30)")
    ap.add_argument("--out", default="resultados", help="Carpeta de salida")
    ap.add_argument("--demo", action="store_true", help="Genera una base sintética con patrones ocultos y la analiza")
    args = ap.parse_args()

    cfg = Cfg(
        tp_pct=args.tp, sl_pct=args.sl,
        fut_threshold_pct=args.future_threshold,
        fut_horizons_min=tuple(int(x) for x in args.horizons.split(",")),
        out_dir=args.out,
    )

    db_path = args.db
    if args.demo:
        from demo_data import generate_demo_db
        db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_pumpfun.db")
        log("🧪 [1/7] Generando base de datos sintética de demostración...")
        generate_demo_db(db_path)
    if not db_path or not os.path.exists(db_path):
        log("❌ Indica tu base con --db ruta.db (o usa --demo para probar con datos sintéticos).")
        return 1

    log(f"\n🔎 [2/7] Inspeccionando esquema de {db_path} ...")
    sm = inspect_db(db_path)
    if args.mapping:
        apply_mapping_override(sm, args.mapping)
    log(schema_report(sm))

    log("\n📥 [3/7] Cargando y normalizando datos...")
    d = load_data(db_path, sm)
    n_tok = len(d.tokens) if d.tokens is not None else 0
    n_tr = len(d.trades) if d.trades is not None else 0
    n_my = len(d.my) if d.my is not None else 0
    log(f"   tokens={n_tok:,} · trades={n_tr:,} · posiciones propias={n_my:,} · rutas de precio={len(d.paths):,}")
    if not d.paths and n_my == 0:
        log("❌ No hay datos de precios ni trades propios que analizar. Revisa el mapeo (--mapping).")
        return 1

    log("\n🛠️ [4/7] Construyendo características de tokens y operaciones...")
    tokfeat = token_features(d, cfg)
    virtual = False
    if d.my is not None and len(d.my):
        trades_df = trade_features(d, tokfeat, cfg)
    else:
        log("   (sin tabla de trades propios → simulando entradas virtuales de sniping "
            f"a los {cfg.virtual_entry_s:.0f}s de cada token)")
        vt = build_virtual_trades(d, cfg)
        if not len(vt):
            log("❌ No se pudieron construir entradas virtuales (faltan rutas de precio).")
            return 1
        trades_df = trade_features(d, tokfeat, cfg, base_df=vt)
        virtual = True
    # Excluir del minado las columnas de RESULTADO (fuga de información):
    # solo deben usarse features conocidas en el momento de la entrada.
    cfg.exclude_features = tuple(cfg.exclude_features) + (
        "pnl_sol", "pnl_pct", "exit_price", "exit_time", "hold_s", "status",
        "win", "virtual", "graduated", "tpsl_timeout", "entry_price",
        "market_cap", "mc_at_entry_est", "fees", "raw_wallet", "raw_tx_signature",
    )
    log(f"   features por token: {tokfeat.shape[1]-1} · operaciones a analizar: {len(trades_df):,}")

    log("\n🏷️ [5/7] Calculando etiquetas de win (real, TP/SL, futuros, graduación)...")
    trades_df = compute_trade_labels(d, trades_df, cfg)
    label_cols = []
    for lc in ["win_real", "win_tp_sl"] + [f"win_fut_{h}m" for h in cfg.fut_horizons_min] + ["win_grad"]:
        if lc in trades_df.columns and trades_df[lc].notna().sum() >= 20:
            label_cols.append(lc)
            s = trades_df[lc].dropna()
            log(f"   {lc:<14} n={len(s):>6,}  winrate={s.mean()*100:5.1f}%")
    if not label_cols:
        log("❌ Ninguna etiqueta alcanzó el mínimo de 20 muestras. Revisa el mapeo.")
        return 1

    main_label = next((lc for lc in ("win_tp_sl", "win_real", "win_fut_15m", "win_fut_5m",
                                      "win_fut_30m", "win_grad") if lc in label_cols), label_cols[0])

    log("\n⛏️ [6/7] Minando patrones por etiqueta...")
    results = {
        "db_path": db_path, "schema": sm, "cfg": cfg, "labels_df": trades_df,
        "tokfeat": tokfeat, "label_cols": label_cols, "main_label": main_label,
        "univariate": {}, "rules": {}, "models": {}, "inter": {}, "spread": {},
        "warnings": list(d.warnings), "virtual": virtual,
        "pnl_total": float(trades_df["pnl_sol"].sum()) if "pnl_sol" in trades_df.columns else None,
    }
    for lc in label_cols:
        log(f"   → {lc}")
        results["univariate"][lc] = univariate(trades_df, lc, cfg)
        results["spread"][lc] = feature_spread(results["univariate"][lc])
        results["rules"][lc] = tree_rules(trades_df, lc, cfg)
        results["models"][lc] = model_eval(trades_df, lc, cfg)
        m = results["models"][lc]
        imp_feats = list(m["importance"].index) if m.get("ok") and len(m.get("importance", [])) else \
            results["spread"][lc].head(8)["feature"].tolist() if len(results["spread"][lc]) else []
        results["inter"][lc] = interactions(trades_df, lc, imp_feats, cfg)

    results["grid"] = tpsl_grid(d, trades_df, cfg)
    results["mfe_mae"] = mfe_mae_summary(trades_df)

    log("\n📝 [7/7] Generando reporte...")
    os.makedirs(cfg.out_dir, exist_ok=True)
    report_path = build_report(results, cfg.out_dir)

    # hallazgos.csv con todas las reglas y estadísticas univariadas
    hall = []
    for lc in label_cols:
        r = results["rules"].get(lc)
        if r is not None and len(r):
            rr = r.copy()
            rr["tipo"] = "regla"
            hall.append(rr[["tipo", "label", "rule", "n", "wins", "winrate", "baseline", "lift", "p_value"]])
        u = results["univariate"].get(lc)
        if u is not None and len(u):
            uu = u.rename(columns={"bin": "rule"}).copy()
            uu["tipo"] = "univariado"
            uu["label"] = lc
            uu["wins"] = uu["wins"]
            hall.append(uu[["tipo", "label", "rule", "n", "wins", "winrate", "baseline", "lift", "p_value"]])
    if hall:
        pd.concat(hall, ignore_index=True).to_csv(
            os.path.join(cfg.out_dir, "hallazgos.csv"), index=False, encoding="utf-8-sig")

    # resumen final por consola
    log("\n" + "=" * 72)
    log("RESUMEN DE HALLAZGOS")
    log("=" * 72)
    r = results["rules"].get(main_label)
    if r is not None and len(r):
        top = r.head(8)
        for t in top.itertuples():
            log(f"  [{'+' if t.lift >= 1 else '-'}] lift {t.lift:5.2f}x · winrate {t.winrate*100:5.1f}% "
                f"(base {t.baseline*100:.1f}%) · n={t.n:>4} · p={t.p_value:.2g} · SI {t.rule}")
    else:
        log("  Sin reglas significativas para la etiqueta principal.")
    if results.get("grid", {}).get("expectancy"):
        ex = results["grid"]["expectancy"]
        best = max(ex, key=lambda k: ex[k])
        log(f"\n  Mejor política de salidas del grid: TP +{best[0]}% / SL -{best[1]}% "
            f"→ expectancy {ex[best]:+.2f}R, winrate {results['grid']['winrate'][best]*100:.0f}%")
    log(f"\n  📄 Reporte completo: {report_path}")
    log(f"  📄 Hallazgos (CSV):  {os.path.join(cfg.out_dir, 'hallazgos.csv')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
