"""Detector de patrones de trading para memecoins de pump.fun."""
__version__ = "1.0.0"
